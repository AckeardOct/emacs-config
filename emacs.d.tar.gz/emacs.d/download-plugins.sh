#!/bin/bash

mkdir ~/.emacs.d/git

cd ~/.emacs.d/git/

# ========== NAV
git clone https://github.com/ancane/emacs-nav.git

# ========== D-MODE
git clone https://github.com/Emacs-D-Mode-Maintainers/Emacs-D-Mode.git